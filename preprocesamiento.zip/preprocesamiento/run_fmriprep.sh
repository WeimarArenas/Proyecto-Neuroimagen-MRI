#!/bin/bash
# =============================================================================
# run_fmriprep.sh — Pipeline de preprocesamiento fMRI con fMRIPrep vía Docker
# =============================================================================
# Este script itera sobre todos los sujetos de un dataset BIDS y ejecuta
# fMRIPrep en cada uno de forma secuencial usando Docker.
#
# fMRIPrep realiza automáticamente:
#   - Corrección de movimiento de cabeza (head motion correction)
#   - Corrección de tiempo de adquisición de cortes (slice timing)
#   - Registro a espacio anatómico (co-registro BOLD ↔ T1w)
#   - Normalización al espacio estándar MNI152 (para análisis de grupo)
#   - Generación de confounds (movimiento, señales de CSF/WM, etc.)
#   - Generación de figuras QC (quality control) por sujeto
#
# REQUISITOS:
#   - Docker instalado y corriendo
#   - Imagen nipreps/fmriprep:24.1.1 descargada (docker pull nipreps/fmriprep:24.1.1)
#   - Dataset en formato BIDS con dataset_description.json
#   - Licencia de FreeSurfer (gratis en https://surfer.nmr.mgh.harvard.edu/registration.html)
#
# EJECUCIÓN (desde WSL o bash):
#   bash run_fmriprep.sh
# =============================================================================

# -----------------------------------------------------------------------------
# RUTAS PRINCIPALES
# Nota: Se usan rutas /mnt/c/... porque el script corre en WSL (Windows
# Subsystem for Linux). Docker monta estas rutas dentro del contenedor.
# -----------------------------------------------------------------------------

# Directorio raíz del dataset BIDS (contiene sub-XX/, dataset_description.json, etc.)
BIDS_DIR="/mnt/c/Users/ASUS/Desktop/OpenNeuro/datos_originales"

# Directorio donde fMRIPrep escribirá sus resultados (archivos NIfTI preprocesados,
# confounds TSV, figuras HTML de QC, etc.)
OUTPUT_DIR="/mnt/c/Users/ASUS/Desktop/OpenNeuro/preprocesamiento"

# -----------------------------------------------------------------------------
# OPCIONES DE FreeSurfer
# FreeSurfer hace reconstrucción de superficie cortical (pial, white matter, etc.)
# y permite análisis en espacio de superficie. Requiere ~8-12 h extra por sujeto.
# Para análisis de volumen en MNI (como este pipeline) no es necesario → FS_FLAG=0
# -----------------------------------------------------------------------------
# 0 = deshabilitado (--fs-no-reconall), 1 = habilitado
FS_FLAG=0

# Ruta al archivo de licencia de FreeSurfer.
# fMRIPrep la requiere aunque FreeSurfer esté deshabilitado (verificación interna).
FS_LICENSE="/mnt/c/Users/ASUS/Desktop/OpenNeuro/license.txt"

# -----------------------------------------------------------------------------
# PARÁMETROS DE DOCKER / fMRIPrep
# -----------------------------------------------------------------------------

# Versión exacta de la imagen Docker de fMRIPrep a usar.
# Fijar la versión garantiza reproducibilidad (mismos resultados en cualquier máquina).
FMRIPREP_VERSION="24.1.1"

# Número de núcleos de CPU disponibles para fMRIPrep.
# fMRIPrep paraleliza internamente varios pasos (ej. registro, ICA-AROMA).
# Con N_CPUS=8 cada sujeto usa hasta 8 hilos simultáneos.
N_CPUS=8

# Límite de memoria RAM en GB.
# MEM_GB=2 es puede llegar a ser ajustado; si hay errores de memoria, aumentar a 8-16.
MEM_GB=2

# Espacios de salida para la normalización espacial:
#   MNI152NLin2009cAsym:res-2 → espacio MNI estándar a resolución 2mm isotrópica
#                                (necesario para análisis de grupo en ICA/conn)
#   anat                       → espacio T1w nativo del sujeto (útil para QC)
OUTPUT_SPACES="MNI152NLin2009cAsym:res-2 anat"

# Directorio de trabajo temporal de fMRIPrep.
# Almacena archivos intermedios de Nipype/Niworkflows (registros, transformaciones, etc.)
# Puede ocupar 10-20 GB por sujeto. Se puede borrar al finalizar para recuperar espacio.
WORK_DIR="/mnt/c/Users/ASUS/Desktop/OpenNeuro/work"

# -----------------------------------------------------------------------------
# VALIDACIÓN INICIAL
# Antes de procesar ningún sujeto, verifica que el entorno esté bien configurado.

echo "============================================="
echo " fMRIPrep Preprocessing Pipeline"
echo "============================================="
echo ""
echo " BIDS Directory : ${BIDS_DIR}"
echo " Output Directory : ${OUTPUT_DIR}"
echo " FreeSurfer       : $([ ${FS_FLAG} -eq 1 ] && echo 'ENABLED' || echo 'DISABLED')"
echo " fMRIPrep Version : ${FMRIPREP_VERSION}"
echo " CPUs per subject : ${N_CPUS}"
echo " Memory limit     : ${MEM_GB} GB"
echo "============================================="
echo ""

# Verifica que el directorio BIDS exista
if [ ! -d "${BIDS_DIR}" ]; then
    echo "ERROR: BIDS directory not found: ${BIDS_DIR}"
    exit 1
fi

# Verifica que dataset_description.json esté presente.
# fMRIPrep requiere este archivo para validar que el dataset cumple el estándar BIDS.
if [ ! -f "${BIDS_DIR}/dataset_description.json" ]; then
    echo "ERROR: dataset_description.json not found. Is this a valid BIDS dataset?"
    exit 1
fi

# Verifica la licencia de FreeSurfer.
# Si FS_FLAG=1 y no hay licencia → error fatal.
# Si FS_FLAG=0 y no hay licencia → advertencia (fMRIPrep puede quejarse igualmente).
if [ ! -f "${FS_LICENSE}" ]; then
    echo "WARNING: FreeSurfer license not found at ${FS_LICENSE}"
    echo "         You can obtain one free at: https://surfer.nmr.mgh.harvard.edu/registration.html"
    if [ ${FS_FLAG} -eq 1 ]; then
        echo "ERROR: FreeSurfer is enabled but license file is missing. Exiting."
        exit 1
    fi
fi

# Crea los directorios de salida y trabajo si no existen.
# -p no falla si ya existen ni si hay que crear múltiples niveles.
mkdir -p "${OUTPUT_DIR}"
mkdir -p "${WORK_DIR}"

# -----------------------------------------------------------------------------
# CONSTRUCCIÓN DE LA OPCIÓN DE FREESURFER
# Según FS_FLAG, se añade o no el flag --fs-no-reconall al comando de fMRIPrep.
# -----------------------------------------------------------------------------

if [ ${FS_FLAG} -eq 0 ]; then
    FS_OPTION="--fs-no-reconall"
    echo "INFO: FreeSurfer reconstruction DISABLED (--fs-no-reconall)"
else
    FS_OPTION=""
    echo "INFO: FreeSurfer reconstruction ENABLED"
fi

# -----------------------------------------------------------------------------
# DETECCIÓN AUTOMÁTICA DE SUJETOS
# Busca todos los directorios que empiecen por "sub-" en el BIDS_DIR.
# -maxdepth 1 → solo un nivel (no busca dentro de sub-carpetas)
# -printf "%f\n" → imprime solo el nombre del directorio, sin la ruta completa
# sort → ordena alfabéticamente para procesar en orden consistente
# -----------------------------------------------------------------------------

SUBJECTS=($(find "${BIDS_DIR}" -maxdepth 1 -type d -name "sub-*" -printf "%f\n" | sort))

TOTAL=${#SUBJECTS[@]}

if [ ${TOTAL} -eq 0 ]; then
    echo "ERROR: No subjects found in ${BIDS_DIR}"
    exit 1
fi

echo ""
echo "Found ${TOTAL} subjects: ${SUBJECTS[*]}"
echo ""

# -----------------------------------------------------------------------------
# BUCLE PRINCIPAL — UN SUJETO A LA VEZ
# fMRIPrep se ejecuta de forma secuencial (no paralela entre sujetos) para
# evitar saturar la RAM. Dentro de cada sujeto, fMRIPrep sí usa múltiples
# hilos (N_CPUS) para paralelizar sus pasos internos.
# -----------------------------------------------------------------------------

FAILED=()   # Lista de sujetos que fallaron
SUCCESS=()  # Lista de sujetos que completaron exitosamente
START_TIME=$(date +%s)  # Marca de tiempo de inicio (segundos desde epoch)

for i in "${!SUBJECTS[@]}"; do
    SUB=${SUBJECTS[$i]}
    # fMRIPrep usa --participant-label sin el prefijo "sub-"
    # Ej: "sub-00" → "00"
    SUB_ID=${SUB#sub-}
    CURRENT=$((i + 1))

    echo "---------------------------------------------"
    echo " Processing ${SUB} (${CURRENT}/${TOTAL})"
    echo " Started at: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "---------------------------------------------"

    # -------------------------------------------------------------------------
    # COMANDO DOCKER DE fMRIPrep
    # Monta las carpetas del host dentro del contenedor con -v host:contenedor
    #
    #   --rm          → elimina el contenedor al terminar (no acumula contenedores)
    #   -it           → terminal interactivo (permite ver logs en tiempo real)
    #   -v BIDS:/data:ro → BIDS_DIR montado como solo lectura (fMRIPrep no modifica originales)
    #   -v OUT:/out   → OUTPUT_DIR donde fMRIPrep escribe sus resultados
    #   -v WORK:/work → WORK_DIR para archivos intermedios (Nipype cache)
    #   -v LICENSE    → licencia de FreeSurfer montada en la ruta que fMRIPrep espera
    #
    # Argumentos posicionales de fMRIPrep:
    #   /data          → dataset BIDS de entrada
    #   /out           → directorio de salida
    #   participant    → nivel de análisis (procesa un sujeto a la vez)
    #
    # Argumentos clave:
    #   --participant-label → qué sujeto procesar en esta iteración
    #   --output-spaces     → espacios de normalización de salida
    #   --nprocs            → hilos de CPU disponibles
    #   --mem-mb            → límite de RAM en MB (MEM_GB × 1024)
    #   --work-dir          → dónde guardar intermedios de Nipype
    #   --skip_bids_validation → omite validación BIDS (más rápido; usar con cuidado)
    #   --stop-on-first-crash  → aborta el sujeto al primer error (evita procesar de más)
    # -------------------------------------------------------------------------
    docker run --rm -it \
        -v "${BIDS_DIR}":/data:ro \
        -v "${OUTPUT_DIR}":/out \
        -v "${WORK_DIR}":/work \
        -v "${FS_LICENSE}":/opt/freesurfer/license.txt:ro \
        nipreps/fmriprep:${FMRIPREP_VERSION} \
        /data /out participant \
        --participant-label "${SUB_ID}" \
        --output-spaces ${OUTPUT_SPACES} \
        --nprocs ${N_CPUS} \
        --mem-mb $((MEM_GB * 1024)) \
        --work-dir /work \
        --skip_bids_validation \
        --stop-on-first-crash \
        ${FS_OPTION}

    # $? contiene el código de salida del último comando (0 = éxito, ≠0 = error)
    if [ $? -eq 0 ]; then
        echo "SUCCESS: ${SUB} completed."
        SUCCESS+=("${SUB}")
    else
        echo "FAILED: ${SUB} encountered an error."
        FAILED+=("${SUB}")
        # El bucle NO se interrumpe: continúa con el siguiente sujeto
    fi

    echo ""
done

# -----------------------------------------------------------------------------
# RESUMEN FINAL
# -----------------------------------------------------------------------------

END_TIME=$(date +%s)
# Tiempo transcurrido total en minutos
ELAPSED=$(( (END_TIME - START_TIME) / 60 ))

echo "============================================="
echo " PREPROCESSING COMPLETE"
echo "============================================="
echo " Total time     : ${ELAPSED} minutes"
echo " Successful     : ${#SUCCESS[@]}/${TOTAL}"
echo " Failed         : ${#FAILED[@]}/${TOTAL}"

# Si hubo fallos, lista los sujetos para revisión manual de logs en WORK_DIR
if [ ${#FAILED[@]} -gt 0 ]; then
    echo " Failed subjects: ${FAILED[*]}"
    echo " Revisar logs en: ${WORK_DIR}"
fi

echo ""
echo " Results saved to: ${OUTPUT_DIR}"
echo "============================================="